export interface ILuchador {
  nombre: string;
  retrato: string;
  animacion: string;
  fuerza: number;
  destreza: number;
  vida: number;
  colorAsociado: string;
}
