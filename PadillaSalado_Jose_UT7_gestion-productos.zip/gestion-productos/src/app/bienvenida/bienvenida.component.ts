import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-bienvenida',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './bienvenida.component.html',
})
export class BienvenidaComponent {

}
